// Sample data for warranty claims
const warrantyData = [
  {
    id: "WC-2023-001",
    product: "Professional Laptop",
    customer: "John Smith",
    status: "Approved",
    date: "2023-11-01",
    value: 450.00
  },
  {
    id: "WC-2023-002",
    product: "Wireless Headphones",
    customer: "Sarah Johnson",
    status: "Pending",
    date: "2023-11-02",
    value: 89.99
  },
  {
    id: "WC-2023-003",
    product: "Gaming Monitor",
    customer: "Mike Brown",
    status: "Processing",
    date: "2023-11-03",
    value: 299.99
  },
  {
    id: "WC-2023-004",
    product: "Mechanical Keyboard",
    customer: "Emma Davis",
    status: "Rejected",
    date: "2023-11-04",
    value: 129.99
  }
];

// Sample data for warranty claims status
const warrantyStatusData = [
  {
    id: "WCS-001",
    claimId: "WC-2023-001",
    issueDate: "2023-10-15",
    category: "Hardware",
    priority: "High",
    resolution: "Replacement"
  },
  {
    id: "WCS-002",
    claimId: "WC-2023-002",
    issueDate: "2023-10-20",
    category: "Accessories",
    priority: "Medium",
    resolution: "Repair"
  }
];

// Sample data for opportunity assessment
const opportunityData = [
  {
    id: "OPP-001",
    statusId: "WCS-001",
    potentialValue: 25000,
    marketSize: "Large",
    growthRate: "15%",
    riskLevel: "Medium"
  },
  {
    id: "OPP-002",
    statusId: "WCS-002",
    potentialValue: 15000,
    marketSize: "Medium",
    growthRate: "10%",
    riskLevel: "Low"
  }
];

// Sample data for recommendations
const recommendationsData = [
  {
    id: "REC-001",
    opportunityId: "OPP-001",
    action: "Expand Product Line",
    impact: "High",
    timeframe: "6 months",
    cost: "$50,000"
  },
  {
    id: "REC-002",
    opportunityId: "OPP-002",
    action: "Market Penetration",
    impact: "Medium",
    timeframe: "3 months",
    cost: "$25,000"
  }
];

// Sample data for engine priorities
const enginePrioritiesData = [
  {
    id: "ENG-001",
    recommendationId: "REC-001",
    engineType: "Type A",
    efficiency: "95%",
    maintenanceCost: "$2,000/month",
    lifespan: "10 years"
  },
  {
    id: "ENG-002",
    recommendationId: "REC-002",
    engineType: "Type B",
    efficiency: "92%",
    maintenanceCost: "$1,500/month",
    lifespan: "8 years"
  }
];

// Sample data for invoices
const invoiceData = [
  {
    id: "INV-2023-001",
    client: "Tech Solutions Inc.",
    amount: 2499.99,
    status: "Paid",
    dueDate: "2023-11-15"
  },
  {
    id: "INV-2023-002",
    client: "Digital Services LLC",
    amount: 1899.99,
    status: "Pending",
    dueDate: "2023-11-20"
  },
  {
    id: "INV-2023-003",
    client: "Creative Studios",
    amount: 3299.99,
    status: "Overdue",
    dueDate: "2023-11-01"
  },
  {
    id: "INV-2023-004",
    client: "Global Systems Corp",
    amount: 4999.99,
    status: "Processing",
    dueDate: "2023-11-30"
  }
];

let selectedWarrantyClaim = null;
let selectedWarrantyStatus = null;
let selectedOpportunity = null;
let selectedRecommendation = null;

// Initialize the dashboard
document.addEventListener('DOMContentLoaded', () => {
  // Populate tables
  populateWarrantyTable();
  populateInvoiceTable();
  
  // Setup navigation
  setupNavigation();
  
  // Setup sidebar toggle
  setupSidebarToggle();

  // Setup table navigation
  setupTableNavigation();
});

function setupTableNavigation() {
  // Warranty table row selection
  document.querySelector('#warrantyTable').addEventListener('click', (e) => {
    const row = e.target.closest('tr');
    if (row) {
      document.querySelectorAll('#warrantyTable tr').forEach(r => r.classList.remove('table-active'));
      row.classList.add('table-active');
      selectedWarrantyClaim = warrantyData.find(w => w.id === row.cells[0].textContent);
      document.querySelector('#proceedToStatus').disabled = false;
    }
  });

  // Status table row selection
  document.querySelector('#statusTable').addEventListener('click', (e) => {
    const row = e.target.closest('tr');
    if (row) {
      document.querySelectorAll('#statusTable tr').forEach(r => r.classList.remove('table-active'));
      row.classList.add('table-active');
      selectedWarrantyStatus = warrantyStatusData.find(w => w.id === row.cells[0].textContent);
      document.querySelector('#proceedToOpportunity').disabled = false;
    }
  });

  // Opportunity table row selection
  document.querySelector('#opportunityTable').addEventListener('click', (e) => {
    const row = e.target.closest('tr');
    if (row) {
      document.querySelectorAll('#opportunityTable tr').forEach(r => r.classList.remove('table-active'));
      row.classList.add('table-active');
      selectedOpportunity = opportunityData.find(o => o.id === row.cells[0].textContent);
      document.querySelector('#proceedToRecommendations').disabled = false;
    }
  });

  // Recommendations table row selection
  document.querySelector('#recommendationsTable').addEventListener('click', (e) => {
    const row = e.target.closest('tr');
    if (row) {
      document.querySelectorAll('#recommendationsTable tr').forEach(r => r.classList.remove('table-active'));
      row.classList.add('table-active');
      selectedRecommendation = recommendationsData.find(r => r.id === row.cells[0].textContent);
      document.querySelector('#proceedToEngines').disabled = false;
    }
  });

  // Button click handlers
  document.querySelector('#proceedToStatus').addEventListener('click', () => {
    if (selectedWarrantyClaim) {
      document.querySelector('#warrantySection').style.display = 'none';
      document.querySelector('#statusSection').style.display = 'block';
      populateStatusTable();
    }
  });

  document.querySelector('#proceedToOpportunity').addEventListener('click', () => {
    if (selectedWarrantyStatus) {
      document.querySelector('#statusSection').style.display = 'none';
      document.querySelector('#opportunitySection').style.display = 'block';
      populateOpportunityTable();
    }
  });

  document.querySelector('#proceedToRecommendations').addEventListener('click', () => {
    if (selectedOpportunity) {
      document.querySelector('#opportunitySection').style.display = 'none';
      document.querySelector('#recommendationsSection').style.display = 'block';
      populateRecommendationsTable();
    }
  });

  document.querySelector('#proceedToEngines').addEventListener('click', () => {
    if (selectedRecommendation) {
      document.querySelector('#recommendationsSection').style.display = 'none';
      document.querySelector('#enginesSection').style.display = 'block';
      populateEnginesTable();
    }
  });

  // Back button handlers
  document.querySelectorAll('.backButton').forEach(button => {
    button.addEventListener('click', (e) => {
      const currentSection = e.target.closest('.section');
      const previousSection = currentSection.previousElementSibling;
      
      currentSection.style.display = 'none';
      previousSection.style.display = 'block';
    });
  });
}

function populateWarrantyTable() {
  const tbody = document.querySelector('#warrantyTable');
  tbody.innerHTML = warrantyData.map(claim => `
    <tr>
      <td>${claim.id}</td>
      <td>${claim.product}</td>
      <td>${claim.customer}</td>
      <td>
        <span class="status-badge status-${claim.status.toLowerCase()}">
          ${claim.status}
        </span>
      </td>
      <td>${formatDate(claim.date)}</td>
      <td>$${claim.value.toFixed(2)}</td>
    </tr>
  `).join('');
}

function populateStatusTable() {
  const tbody = document.querySelector('#statusTable');
  const filteredStatus = warrantyStatusData.filter(status => status.claimId === selectedWarrantyClaim.id);
  
  tbody.innerHTML = filteredStatus.map(status => `
    <tr>
      <td>${status.id}</td>
      <td>${status.issueDate}</td>
      <td>${status.category}</td>
      <td>${status.priority}</td>
      <td>${status.resolution}</td>
    </tr>
  `).join('');
}

function populateOpportunityTable() {
  const tbody = document.querySelector('#opportunityTable');
  const filteredOpportunities = opportunityData.filter(opp => opp.statusId === selectedWarrantyStatus.id);
  
  tbody.innerHTML = filteredOpportunities.map(opp => `
    <tr>
      <td>${opp.id}</td>
      <td>$${opp.potentialValue.toLocaleString()}</td>
      <td>${opp.marketSize}</td>
      <td>${opp.growthRate}</td>
      <td>${opp.riskLevel}</td>
    </tr>
  `).join('');
}

function populateRecommendationsTable() {
  const tbody = document.querySelector('#recommendationsTable');
  const filteredRecommendations = recommendationsData.filter(rec => rec.opportunityId === selectedOpportunity.id);
  
  tbody.innerHTML = filteredRecommendations.map(rec => `
    <tr>
      <td>${rec.id}</td>
      <td>${rec.action}</td>
      <td>${rec.impact}</td>
      <td>${rec.timeframe}</td>
      <td>${rec.cost}</td>
    </tr>
  `).join('');
}

function populateEnginesTable() {
  const tbody = document.querySelector('#enginesTable');
  const filteredEngines = enginePrioritiesData.filter(eng => eng.recommendationId === selectedRecommendation.id);
  
  tbody.innerHTML = filteredEngines.map(eng => `
    <tr>
      <td>${eng.id}</td>
      <td>${eng.engineType}</td>
      <td>${eng.efficiency}</td>
      <td>${eng.maintenanceCost}</td>
      <td>${eng.lifespan}</td>
    </tr>
  `).join('');
}

function populateInvoiceTable() {
  const tbody = document.querySelector('#invoiceTable');
  tbody.innerHTML = invoiceData.map(invoice => `
    <tr>
      <td>${invoice.id}</td>
      <td>${invoice.client}</td>
      <td>$${invoice.amount.toFixed(2)}</td>
      <td>
        <span class="status-badge status-${invoice.status.toLowerCase()}">
          ${invoice.status}
        </span>
      </td>
      <td>${formatDate(invoice.dueDate)}</td>
      <td>
        <button class="btn btn-sm btn-outline-primary">
          <i class="bi bi-eye"></i> View
        </button>
      </td>
    </tr>
  `).join('');
}

function setupNavigation() {
  const navLinks = document.querySelectorAll('.nav-link');
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      
      // Update active states
      navLinks.forEach(l => l.parentElement.classList.remove('active'));
      link.parentElement.classList.add('active');
      
      // Show corresponding page
      const pageId = link.dataset.page + 'Page';
      document.querySelectorAll('.page-content').forEach(page => {
        page.classList.remove('active');
      });
      document.getElementById(pageId).classList.add('active');
      
      // Update page title
      document.getElementById('pageTitle').textContent = link.textContent.trim();

      // Reset warranty workflow
      resetWarrantyWorkflow();
    });
  });
}

function resetWarrantyWorkflow() {
  selectedWarrantyClaim = null;
  selectedWarrantyStatus = null;
  selectedOpportunity = null;
  selectedRecommendation = null;

  document.querySelector('#warrantySection').style.display = 'block';
  document.querySelector('#statusSection').style.display = 'none';
  document.querySelector('#opportunitySection').style.display = 'none';
  document.querySelector('#recommendationsSection').style.display = 'none';
  document.querySelector('#enginesSection').style.display = 'none';

  document.querySelector('#proceedToStatus').disabled = true;
  document.querySelector('#proceedToOpportunity').disabled = true;
  document.querySelector('#proceedToRecommendations').disabled = true;
  document.querySelector('#proceedToEngines').disabled = true;
}

function setupSidebarToggle() {
  document.getElementById('sidebarCollapse').addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('active');
  });
}

function formatDate(dateString) {
  const options = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
}